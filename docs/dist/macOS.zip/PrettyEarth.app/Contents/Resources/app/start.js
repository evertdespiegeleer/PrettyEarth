require = require('esm')(module)
module.exports = require('./index')
// ECMA 6 allowed from here on
exports.setRandomWallPaper = module.exports.setRandomWallPaper
exports.updateMapData = module.exports.updateMapData
exports.quit = module.exports.quit
exports.AutoLauncher = module.exports.AutoLauncher